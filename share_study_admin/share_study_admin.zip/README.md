# share_study_admin

<b>服务端接口由AntonyCheng开发 [https://github.com/AntonyCheng/share_study](https://github.com/AntonyCheng/share_study)</b>

## 基于区块链的教育资源共享平台——后台管理系统

## 项目启动
- 克隆项目 `git clone https://github.com/0Shino0/share_study_admin.git`

- 安装依赖 `npm i` or `yarn`

- 本地运行 `npm run dev`

