import mitt from 'mitt' // Vue3 事件解决方案

export default mitt()