export default {
  message: {
    home: 'home',
      mine: 'mine'
  }
}