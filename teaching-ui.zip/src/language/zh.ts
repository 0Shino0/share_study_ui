export default {
  message: {
    home: '首页',
    mine: '个人中心'
  }
}