const getters = {
  token: state => state.user.token,
  userInfo: state => state.user.userInfo,
  name: state => state.user.name,
}
export default getters
